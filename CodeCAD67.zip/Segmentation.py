# -*- coding: utf-8 -*-
"""
Created on Thu Jul 28 18:48:05 2022

@author: cam
"""
import cv2 as cv
import glob
import numpy as np
import pandas as pd
from scipy.io import loadmat as ldm
import shutil
import os
######## globals####################
dir_path = r"Manual-Segmentation"
dst_mat_path = r"mats"
dst_jpg_path = r"imgs"
gt_path = r"GT"
canny_path = r"cannyEdge"
kmeans_path = r"kMeans"
simple_path = r"simpleThresh"
otsu_path = r"otsuThresh"
resize_path = r"Resize"

file_extension = "/*.*"


################# dice functions ################################################
"""
@param gt_filenames is a file direcotry
This function loops through the given directory
which is given as a parameter each file is added to a list
This list is then returned
@return list of filenames
"""
def filename(gt_filenames):
    filenames = []
    #for each file in the array
    for file in glob.glob(gt_filenames): 
        #append file name to the list
        filenames.append(file)
    return filenames

"""
@param ground is a jpeg file name
@param segment is a jpeg file name
Function takes 2 lists which contain file names
It does a dice score calculation between the 2 files
one a ground trth the other a sample segment
The dice score then gets rounded and returned
@return the dice score value
"""
def diceScore(ground,segment):
    count = 0
    dice_score = []
    while count < len(ground):
        gt = cv.imread(segment[count],0)        
        seg = cv.imread(ground[count],0)
        dice = np.sum(seg)*2.0 / (np.sum(seg) + np.sum(gt))
        
        #rounds the dice
        dice = rounded(dice) 
        dice_score.append(dice)
        count +=1
    return dice_score
    

"""
Creates panda dataframe
Names the panda columns
returns the new panda
@return  panda
"""
def pandas():

    #created df with 2 columns and viewed
    df_dicecoeff = pd.DataFrame(columns=('Segment Image Number','Dice Coefficient'))
    #fix values in columns 
    df_dicecoeff['Segment Image Number'] = df_dicecoeff['Segment Image Number'].astype('int')
    df_dicecoeff['Dice Coefficient'] = df_dicecoeff['Dice Coefficient'].round(decimals = 3)
    
    return df_dicecoeff
    
    

"""
@param panda 
@param segment_dice_score float
This adds the dice_values into the panda

@return the  panda
"""    
def savepandascore(panda,dice_scores):
    ##for loop version for above to save scores in pd df. 
    row = 1
    for score in dice_scores:
        panda.loc[len(panda.index)] = [row, score] 
        row+=1 
    return panda

"""
@param panda
This works out the mean value of the panda
Returns mean dice score
@return mean value
"""
def mean(panda):  

    avg_segment = panda['Dice Coefficient'].mean()
    round(avg_segment, 3)
    return avg_segment

#################################calls  dice functions##############################
"""
@param is mat file
loads the matfile
@return readable matfile
"""
def loadmat(mat):
    matfile = ldm(mat)
    return matfile
    

"""
@param path

Calls the filenamefunction
@return a array of the image files
"""
def imagePaths(path):
 ##gets the filenames in a list
    path_list = filename(path)
        
    
    return path_list

"""
@param ground _truth filename
@param seg filename
Creates a list to store the dice values
calls the function dice_score
returns the dice values from the function
@return dice_value
"""
def diceValues(ground_truth,seg):
    dice_value = []
    #does dice comparing both files
    dice_value = diceScore(ground_truth,seg)
   
    return dice_value


"""
calls the panda function
@return panda
"""
def addPandaHeadings():
    headings = pandas()
    return headings

"""
@param panda
@param dice_value float of dice values
calls the savepandascorefunction
@return panda
"""
def addPandaData(panda,dice_value):
    panda_data = savepandascore(panda,dice_value)
   
    return panda_data

"""
@param panda
Calls the mean function
@return meaan_value a float of the mean value
"""
def pandaMean(panda):
    mean_value = mean(panda)
    return mean_value

  

    

    
#############################mat files functions###########################
"""
@param matfile is a matfile
To get access to the retinal layers aspect of the matfile
Which contains the layers of the retina
@return retinalLayers
"""    
def setupMat(matfile):
    row = 1 # there are 2 fields of image path, retinalLayer and params
    # select 1 or 2
    imageLayer = matfile["imageLayer"][0,row - 1]
    
    
    imagepath = imageLayer[0] # only path of selected row
    retinalLayers = imageLayer[1] # 1x7 Retinal 
    return retinalLayers
    
"""
@param retinal layers contains information
 split x and y to get retinal layers. The x and y correspond to different 
 coordinates of the retinal layers.
 These cordinates are used to plot the different layers of the retina
@return Returns all of the x,y values
"""
def getLayers(retinalLayers):
    pathX1 = retinalLayers[0,0][0][0,:] 
    pathX2 = retinalLayers[0,1][0][0,:]
    pathX3 = retinalLayers[0,2][0][0,:]
    pathX4 = retinalLayers[0,3][0][0,:]
    pathX5 = retinalLayers[0,4][0][0,:]
    pathX6 = retinalLayers[0,5][0][0,:]
    pathX7 = retinalLayers[0,6][0][0,:]
    
    
    
    pathY1 = retinalLayers[0,0][1][0,:] 
    pathY2 = retinalLayers[0,1][1][0,:]
    pathY3 = retinalLayers[0,2][1][0,:]
    pathY4 = retinalLayers[0,3][1][0,:]
    pathY5 = retinalLayers[0,4][1][0,:]
    pathY6 = retinalLayers[0,5][1][0,:]
    pathY7 = retinalLayers[0,6][1][0,:]
    
    #Used to figure out background
    Xmax = (pathX1.max())
    Ymax = (pathY1.max())
   
    #Get +1 of the value
    Xmax = Xmax+1
    Ymax = Ymax+1
   
    
    return pathX1,pathX2,pathX3,pathX4,pathX5,pathX6,pathX7,pathY1,pathY2,pathY3,pathY4,pathY5,pathY6,pathY7,Xmax,Ymax

"""
@param Xmax
@param Ymax
Takes 2 parameters uses those parameters to create a black 
background with thise dimensions
@return blank
"""
def backgound(Xmax,Ymax):
    #This creates a blank 400x400 canvas
    blank = np.zeros((Xmax,Ymax),dtype = 'uint8')
    return blank


"""
@param image
@param pathX
@param pathY
This takes the background and plots the 
coordinates of the ground truth onto it
@return image
"""
def plotImage(image,pathX,pathY):
    

    
    #white is 255
    #black is 0
    white = (255)

    #iterates in parralell
    for x, y in zip(pathX, pathY):
        #Paints the pixels onto the image

                
        image[x,y] = white
                

        
    return image

"""
@param blank
@param pathX1
@param pathY1
This calls the plotting function several times so that all seven 
layers can be plotted onto the image.
X1 and Y1 correspond and so forth.
The finished image is then returned which is the ground truth
@return layer7

"""
def callPlot(blank,pathX1,pathX2,pathX3,pathX4,pathX5,pathX6,pathX7,pathY1,pathY2,pathY3,pathY4,pathY5,pathY6,pathY7):
    layer1= plotImage(blank,pathX1,pathY1)
    #cv.imshow("layer",layer)
    layer2= plotImage(layer1,pathX2,pathY2)
    layer3= plotImage(layer2,pathX3,pathY3)
    layer4= plotImage(layer3,pathX4,pathY4)
    layer5= plotImage(layer4,pathX5,pathY5)
    layer6= plotImage(layer5,pathX6,pathY6)
    layer7= plotImage(layer6,pathX7,pathY7)
    #cv.imshow("layer",layer7)
    #This is the image that is returned
    return layer7


    
 ##################################### mat loop call ####################

"""
@param mat_files_array
This loops through all of the mat files
It calls the functions to create a make a ground truth
The groundtruth is then saved into a file as a jpeg

"""
def loopmat(mat_files_array):
    count = 0
    while count < len(mat_files_array):
        mat = mat_files_array[count]
        matFile = loadmat(mat)
        
        layers = setupMat(matFile)
        pathX1,pathX2,pathX3,pathX4,pathX5,pathX6,pathX7,pathY1,pathY2,pathY3,pathY4,pathY5,pathY6,pathY7,Xmax,Ymax = getLayers(layers)
        bg = backgound(Xmax,Ymax)
        octs = callPlot(bg,pathX1,pathX2,pathX3,pathX4,pathX5,pathX6,pathX7,pathY1,pathY2,pathY3,pathY4,pathY5,pathY6,pathY7)
        
        ######## saves the gt ##############
        #checks to see if file exists if not created
        #saves file to gt folder
        #saves the ground truth
        file_name = mat[4:]
        
        cv.imwrite(gt_path +"/" + str (file_name) + ".jpg", octs)
        #cv.imshow("oct",octs)
        #cv.waitKey(0)
        
        count+= 1


################## Canny Function#############################
"""
Performs canny edge detection onto a series of unprocessed images
 within a folder directory
The canny images are then saved into a seperate file
"""
def canny():
    
    image_path = dst_jpg_path + "/*.*"

    
    for file in glob.glob(image_path):
        
        
        img= cv.imread(file, 0)  #now, we can read each file since we have the full path as grey
        blur = GaussianBlur(img)
        #cannys the image
        cannyy_img = cv.Canny(blur, 150, 175)
        #saves the image to a new file
        
        file_name = file[5:]
        
        
        cv.imwrite(canny_path + "/"+str(file_name)+".jpg", cannyy_img)
        

"""
@param img
This function takes an image and performs gaussian blur on it
The blurred image is then returned
@return blur
"""
def GaussianBlur(img):
    blur = cv.GaussianBlur(img,(5,5), cv.BORDER_DEFAULT)
    return blur
    
############################################################ K means##########################################

"""
This performs k-means clustering on a direcotry of images
The k-means image is then saved into a seperate folder
"""
def kMeans():
    image_path = dst_jpg_path + "/*.*"
    
    for file in glob.glob(image_path):
       
        img= cv.imread(file, 0)  #now, we can read each file since we have the full path as grey
        #median using opencv
        image_median = medianBlur(img)
        
        # convert to RGB
        image = cv.cvtColor(image_median, cv.COLOR_BGR2RGB)
        # reshape the image to a 2D array of pixels and 3 color values (RGB)
        pixel_values = image.reshape((-1, 3))
        # convert to float
        pixel_values = np.float32(pixel_values)
        # define stopping criteria
        criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 100, 0.2)
        # number of clusters (K)
        k = 3 
        _, labels, (centers) = cv.kmeans(pixel_values, k, None, criteria, 10, cv.KMEANS_RANDOM_CENTERS)
        # convert back to 8 bit values
        centers = np.uint8(centers)
        # flatten the labels array
        labels = labels.flatten()
        #construct the segmented image: # convert all pixels to the color of the centroids
        segmented_image = centers[labels.flatten()]
        # reshape back to the original image dimension
        segmented_image = segmented_image.reshape(image.shape)
        
        file_name = file[5:]
        
        
        cv.imwrite(kmeans_path + "/"+str(file_name)+".jpg", segmented_image) ##save as greyscale
  
        
"""
@param img
This takes a parameter which is an image and performs a median blur on it
This blurred image is then returned
@return median
"""
def medianBlur(img):
    median = cv.medianBlur(img, 3) #kernal size 3
    return median

################################################ simple thresh##################################
"""
This performs simple thresholding on a directory of jpeg files
These thresholded images are then saved to another folder
"""
def simpleThresh():
    image_path = dst_jpg_path + "/*.*"
    for file in glob.glob(image_path):
       
        img= cv.imread(file, 0) 
        thresh = cv.threshold(img,200,255,cv.THRESH_BINARY)
        thresh2 = thresh[1:]
        thresh3 = thresh2[0][0:]
        
        file_name = file[5:]
       
        
        cv.imwrite(simple_path + "/"+str(file_name)+".jpg", thresh3) 

        
############################### otsu#################################
"""
This performs otsu thresholding on a directory of jpeg files
These otsu images are then saved to another folder
"""
def otsu():
    image_path = dst_jpg_path + "/*.*"
    for file in glob.glob(image_path):    
        
        img= cv.imread(file, 0)
        blur = cv.GaussianBlur(img,(5,5),0)# Apply GaussianBlur to reduce image noise 
        threshO = cv.threshold(blur, 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU) #Otsu's thresholding after Gaussian filtering
        threshO2 = threshO[1:]
        threshO3= threshO2[0][0:]
        
        
        file_name = file[5:]
       
        cv.imwrite(otsu_path +"/"+str(file_name)+".jpg", threshO3) 
    
    
        
########################################### segment manual segmentation file##################################
"""
This takes a folder which has mat and jpeg files
These files are split into 2 seperate folders
"""

def segmentfile():   
    
    #for each file in the folder
    for path in os.listdir(dir_path):
        #last 3 digits
        #if .mat file move to mats
        if path[-4:] == ".mat":
            src_path = (dir_path +"/" +str(path))
          
            dst_path = (dst_mat_path +"/" + str(path))
            
            shutil.move(src_path, dst_path)
        elif path[-5:] == ".jpeg":
            src_path = (dir_path + "/" + str(path))
           
            dst_path = (dst_jpg_path + "/" + str(path))
           
            shutil.move(src_path, dst_jpg_path)
       

######################################################## resizes jpegs##############
"""
@param path
This takes a file directory as parameter 
Each file within the directory has its dimensions measured 
and appended to the list either height or width dependednt
 on which is gathered
@return height
@return width
"""
def getSize(path):
    heights = []
    widths = []
    image_path = path + "/*.*"
    
    for file in glob.glob(image_path):
       
        img = cv.imread(file)
        width = img.shape[0]
        height = img.shape[1]
        
       
        
        heights.append(height)
        widths.append(width)
        
    return heights,widths


    
"""
@param gt
Has the size of width/height of the ground truth and the sample
This then divides the dimensions of the gt by the sample
This value is then returned 
This value is used to resize images
@param sample
@return z
"""
def resizeparam(gt,sample):
    resized = []
    for x,y in zip(gt,sample):
        resized.append(x/y)
    return resized




"""
@param filename
@param scaleWidth
@param scaleHeight
This takes a file and rescales it
This is so it can be compared to the ground truth
This happens for each file in the directory
The image is then saved to another folder
"""        
def rescaleFrame(file_name,scaleWidth,scaleHeight):
    count = 0    
    
    file_name = file_name + file_extension
    
    for file in glob.glob(file_name):
        img = cv.imread(file)
        
        width = int(img.shape[1] * scaleHeight[count])
     
        height = int(img.shape[0] * scaleWidth[count])
        dimension = (width,height)
        
        
        hi = cv.resize(img,dimension,interpolation=cv.INTER_AREA)  
        #cv.imshow("img",hi)
        filename = file[5:]
        #Saves it to folder Resize
        cv.imwrite(resize_path + "/"+str(filename)+".jpg", hi)
        count += 1
        

#####################################################Final dice score panda ###############################################
"""
@param panda
Updates the panda to have the Canny edge heading
For the final table which shows all of the results
returns the updated panda
@retrun panda
"""
def cannyUpdate(panda):
    panda.rename(columns = {'Dice Coefficient':'Canny Edge Dice Coefficient'}, inplace = True)
    return panda
"""
@param panda
Updates the panda to have the K means heading
For the final table which shows all of the results
returns the updated panda
@retrun panda
"""    
def kmeansUpdate(panda):
    panda.rename(columns = {'Dice Coefficient':'K Means Dice Coefficient'}, inplace = True)
    return panda
"""
@param panda
Updates the panda to have the simple threshold heading
For the final table which shows all of the results
returns the updated panda
@retrun panda
"""    
def simpleUpdate(panda):
    panda.rename(columns = {'Dice Coefficient':'Simple Theshold Dice Coefficient'}, inplace = True)
    return panda
"""
@param panda
Updates the panda to have the otsu heading
For the final table which shows all of the results
returns the updated panda
@retrun panda
"""    
def otsuUpdate(panda):
    panda.rename(columns = {'Dice Coefficient':'Otsu Threshold Dice Coefficient'}, inplace = True)
    return panda

"""
@param canny_df
@param kmeans_df
@param simple_df
@param otsu_df

This merges all of the pandas together on the segment image number
returns one panda full of the results
@retrun df_master panda
"""
def merge(canny_df,kmeans_df,simple_df,otsu_df):
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]
    df_master = pd.DataFrame(data, columns=['Segment Image Number'])
    df_master = pd.merge(pd.merge(pd.merge(canny_df,kmeans_df,on='Segment Image Number'),simple_df,on='Segment Image Number'),otsu_df,on='Segment Image Number')
    return df_master

"""
@param value
Takes a floating point number 
returns the number to 3dp
@return x
"""
def rounded(value):
    x = round(value, 3)
    return x 
    
"""
@param comparison_panda
@param canny mean
It takes a panda and adds the mean values to it
This creates an excel file of the panda
"""
def createExcel(comparison_panda,canny_mean,kmeans_mean,simple_mean,otsu_mean):
    new_row ={'Segment Image Number':'AVG','Canny Edge Dice Coefficient': canny_mean,'K Means Dice Coefficient':kmeans_mean,'Simple Theshold Dice Coefficient':simple_mean,'Otsu Threshold Dice Coefficient':otsu_mean}
    comparison_panda = comparison_panda.append(new_row,ignore_index = True)
    
    
    comparison_panda.to_excel('Dice_Scores.xls', index=False)
    
##############checks to see file exists##############################################
"""
This function is used to see if these files
exist if they do not they are created
"""
def filesExist():
    exists_gt = os.path.exists(gt_path)
    exist_mat = os.path.exists(dst_mat_path)
    exists_jpg = os.path.exists(dst_jpg_path)
    
    exists_canny =  os.path.exists(canny_path)
    exists_kmeans =  os.path.exists(kmeans_path)
    exists_simple =  os.path.exists(simple_path)
    exists_otsu = os.path.exists(otsu_path)
    
    exists_resize = os.path.exists(resize_path)


    if exists_gt == False:
        dir = os.mkdir(gt_path)
    if exist_mat == False:
        dir = os.mkdir(dst_mat_path) 
    if exists_jpg == False:
        dir = os.mkdir(dst_jpg_path) 
        

    if exists_canny == False:
        dir = os.mkdir(canny_path)
    if exists_kmeans == False:
        dir = os.mkdir(kmeans_path) 
    if exists_simple == False:
        dir = os.mkdir(simple_path) 
    if exists_otsu == False:
        dir = os.mkdir(otsu_path)
    if exists_resize == False:
        dir = os.mkdir(resize_path) 
    
    

   

#################################Runs the diffeent sections#################################################
"""
Generates dice score and the mean
"""
def runDice(paths_seg):
    
    path_gt = gt_path + file_extension
    #This changes based on what is run
    #paths_seg = "canny/*.*"
    #ground_list,seg_list = imagePaths(path_gt, paths_seg)
    ground_list = imagePaths(path_gt)
    seg_list = imagePaths(paths_seg)
    
  
    dice_score = diceValues(ground_list,seg_list)
    panda_headings = addPandaHeadings()
    panda_data = addPandaData(panda_headings,dice_score)
    
    mean = pandaMean(panda_data)
    #This is the updated panda
    
    return panda_data, mean

    
"""

This calls the functions which
which converts the mat files to the jpegs
""" 
   
def matFiles():
    
    path = dst_mat_path + file_extension
    
    #Creates a list of the names of all of the path names
    mat_files_array = imagePaths(path)
    
    
    gt = loopmat(mat_files_array)
    
"""
This calls the functions which resizes images
"""
def resizeImages():
     
    sample_height,sample_width= getSize(dst_jpg_path)
    gt_height,gt_width= getSize(gt_path)
    
    param_height = resizeparam(gt_height,sample_height)
    param_width = resizeparam(gt_width,sample_width)
    
   
    
    rescaleFrame(dst_jpg_path,param_width,param_height)
    
"""
This runs the functions which produce dice scores 
and pandas for each segmentation algorithm
"""
def pandaFinal():
    canny_df,canny_mean = runDice(canny_path + file_extension)
    canny_p = cannyUpdate(canny_df)
    
    kmeans_df,kmeans_mean = runDice(kmeans_path + file_extension)
    kmeans_p = kmeansUpdate(kmeans_df)
    simple_df,simple_mean = runDice(simple_path + file_extension)
    simple_p = simpleUpdate(simple_df)
    otsu_df,otsu_mean = runDice(otsu_path + file_extension)
    otsu_p = otsuUpdate(otsu_df)
    
    #gets rounded values
    canny_mean = rounded(canny_mean)
    kmeans_mean = rounded(kmeans_mean)
    simple_mean = rounded(simple_mean)
    otsu_mean = rounded(otsu_mean)
    
    
    comparison_panda = merge(canny_p,kmeans_p,simple_p,otsu_p)
    createExcel(comparison_panda,canny_mean,kmeans_mean,simple_mean,otsu_mean)

    
    

"""
Runs the functions in order
"""
def main():
    #The order files need to be ran

    filesExist()
    segmentfile()
    #This creates the gt
    matFiles()
    resizeImages()
    canny()
    kMeans()
    simpleThresh()
    otsu()
    pandaFinal()
    print("Segmented images saved to named folders if you wish to take a closer look \n")
    print("Please check excel sheet for results")


if __name__ == '__main__':
    main()
    