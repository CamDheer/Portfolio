Manual-Segmentation is a folder which is a collection of mat files whuich are ground truths and corresponding jpegs which are the original image.
The program takes these original image sgements them in various ways and returns a dice score. This dice score shows the simialrity between the ground truth and segmented image.
To run this program you open the program "Segmentation". 
It has the data needed which is supplied in the "Manual-Segmentation" folder